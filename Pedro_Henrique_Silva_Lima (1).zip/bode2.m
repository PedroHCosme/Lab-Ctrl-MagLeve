dados_simulacao = out;

tempo = dados_simulacao.tout;

sinal_de_entrada_obj = dados_simulacao.logsout{1}; 
sinal_de_entrada = sinal_de_entrada_obj.Values.Data;

pos_carro1_planta_obj = dados_simulacao.logsout{2}; 
pos_carro2_planta_obj = dados_simulacao.logsout{3};
pos_carro1_planta = pos_carro1_planta_obj.Values.Data;
pos_carro2_planta = pos_carro2_planta_obj.Values.Data;

pos_carro1_modelo_obj = dados_simulacao.logsout{4}; 
pos_carro2_modelo_obj = dados_simulacao.logsout{5};
pos_carro1_modelo = pos_carro1_modelo_obj.Values.Data;
pos_carro2_modelo = pos_carro2_modelo_obj.Values.Data;

Ts = tempo(2) - tempo(1);
Fs = 1/Ts;
N = length(tempo);

fft_entrada = fft(sinal_de_entrada);

fft_carro1_planta = fft(pos_carro1_planta);
fft_carro2_planta = fft(pos_carro2_planta);
H1_planta = fft_carro1_planta ./ fft_entrada;
H2_planta = fft_carro2_planta ./ fft_entrada;

fft_carro1_modelo = fft(pos_carro1_modelo);
fft_carro2_modelo = fft(pos_carro2_modelo);
H1_modelo = fft_carro1_modelo ./ fft_entrada;
H2_modelo = fft_carro2_modelo ./ fft_entrada;

f = (0:N-1)*(Fs/N); 
w = 2*pi*f;         
range = 1:floor(N/2);

figure('Name', 'Validação Bode - Carrinho 1');
subplot(2,1,1);
semilogx(w(range), 20*log10(abs(H1_planta(range)))); % Planta em azul
hold on;
semilogx(w(range), 20*log10(abs(H1_modelo(range)))); % Modelo em vermelho
hold off;
ylabel('|X_1/F| (dB)');
grid on;
xlim([0.1, 30]); 

subplot(2,1,2);
semilogx(w(range), unwrap(angle(H1_planta(range)))*180/pi);
hold on;
semilogx(w(range), unwrap(angle(H1_modelo(range)))*180/pi);
hold off;
ylabel('Fase (graus)');
xlabel('Frequência (rad/s)');
grid on;
xlim([0.1, 30]); 


figure('Name', 'Validação Bode - Carrinho 2');
subplot(2,1,1);
semilogx(w(range), 20*log10(abs(H2_planta(range))));
hold on;
semilogx(w(range), 20*log10(abs(H2_modelo(range))));
hold off;
ylabel('|X_2/F| (dB)');
grid on;
xlim([0.1, 30]); 

subplot(2,1,2);
semilogx(w(range), unwrap(angle(H2_planta(range)))*180/pi);
hold on;
semilogx(w(range), unwrap(angle(H2_modelo(range)))*180/pi);
hold off;
ylabel('Fase (graus)');
xlabel('Frequência (rad/s)');
grid on;
xlim([0.1, 30]);

disp('Gráficos de Bode comparativos gerados com sucesso!');