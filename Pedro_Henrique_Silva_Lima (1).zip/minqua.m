
disp('Iniciando estimação (com unidades corrigidas)...');

dados_simulacao = out;
tempo_saida = dados_simulacao.tout;
Ts = tempo_saida(2) - tempo_saida(1);

F_in_obj = dados_simulacao.logsout{1};
x1_obj   = dados_simulacao.logsout{4};
x2_obj   = dados_simulacao.logsout{5};
a1_obj   = dados_simulacao.logsout{2}; 
a2_obj   = dados_simulacao.logsout{3}; 

x1_counts = x1_obj.Values.Data;
x2_counts = x2_obj.Values.Data;
a1_raw    = a1_obj.Values.Data; 
a2_raw    = a2_obj.Values.Data; 
tempo_entrada = F_in_obj.Values.Time;
dados_entrada_counts = F_in_obj.Values.Data;

F_in_counts_long = interp1(tempo_entrada, dados_entrada_counts, tempo_saida, 'previous', 'extrap');

mc = 4.41e-6;  
knc = 5.13e-2; 

x1_m = x1_counts * mc; 
x2_m = x2_counts * mc;
F_in_N = F_in_counts_long * knc; 

a1_mss = a1_raw; 
a2_mss = a2_raw;

v1_ms = diff(x1_m)/Ts;
v2_ms = diff(x2_m)/Ts;

N = length(v1_ms);
F_in = F_in_N(1:N);
x1 = x1_m(1:N);
x2 = x2_m(1:N);
a1 = a1_mss(1:N);
a2 = a2_mss(1:N);
v1 = v1_ms;
v2 = v2_ms;

disp('Estimando parâmetros...');
R1 = [-x1, -(x1 - x2), -v1, F_in];
p1 = (R1'*R1)\(R1'*a1);
m1_est = 1 / p1(4);
k1_est = p1(1) * m1_est;
k12_est_c1 = p1(2) * m1_est;
b1_est = p1(3) * m1_est;

R2 = [-x2, (x1 - x2), -v2];
p2 = (R2'*R2)\(R2'*a2);
m2_est = k12_est_c1 / p2(2);
k2_est = p2(1) * m2_est;
b2_est = p2(3) * m2_est;

fprintf('\n--- RESULTADOS FINAIS (LSQ COM UNIDADES CORRIGIDAS) ---\n');
fprintf('m1 = %.4f\n', m1_est);
fprintf('b1 = %.4f\n', b1_est);
fprintf('k1 = %.4f\n\n', k1_est);
fprintf('k12 = %.4f\n\n', k12_est_c1);
fprintf('m2 = %.4f\n', m2_est);
fprintf('b2 = %.4f\n', b2_est);
fprintf('k2 = %.4f\n', k2_est);
fprintf('-----------------------------------------------------------\n');

