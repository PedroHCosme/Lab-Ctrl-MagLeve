dados_simulacao = out;

tempo = dados_simulacao.tout;
sinal_de_entrada_obj = dados_simulacao.logsout{1}; 
pos_carro1_obj       = dados_simulacao.logsout{4}; 
pos_carro2_obj       = dados_simulacao.logsout{5}; 

sinal_de_entrada = sinal_de_entrada_obj.Values.Data;
pos_carro1       = pos_carro1_obj.Values.Data;
pos_carro2       = pos_carro2_obj.Values.Data;

Ts = tempo(2) - tempo(1);
Fs = 1/Ts;
N = length(tempo);

fft_entrada = fft(sinal_de_entrada);
fft_carro1 = fft(pos_carro1);
fft_carro2 = fft(pos_carro2);

H1 = fft_carro1 ./ fft_entrada;
H2 = fft_carro2 ./ fft_entrada;

f = (0:N-1)*(Fs/N); 
w = 2*pi*f;         

range = 1:floor(N/2);

figure('Name', 'Bode Experimental - Carrinho 1');
subplot(2,1,1);
semilogx(w(range), 20*log10(abs(H1(range))));
ylabel('|X_1/F| (dB)');
grid on;
xlim([0.1, 30]); 

subplot(2,1,2);
semilogx(w(range), unwrap(angle(H1(range)))*180/pi);
ylabel('Fase (graus)');
xlabel('Frequência (rad/s)');
grid on;
xlim([0.1, 30]); 
ylim([-300, 300]); 
figure('Name', 'Bode Experimental - Carrinho 2');
subplot(2,1,1);
semilogx(w(range), 20*log10(abs(H2(range))));
ylabel('|X_2/F| (dB)');
grid on;
xlim([0.1, 30]); 

subplot(2,1,2);
semilogx(w(range), unwrap(angle(H2(range)))*180/pi);
ylabel('Fase (graus)');
xlabel('Frequência (rad/s)');
grid on;
xlim([0.1, 30]);
ylim([-10000, 10000]); 
disp('Gráficos de Bode (range final) gerados com sucesso!');